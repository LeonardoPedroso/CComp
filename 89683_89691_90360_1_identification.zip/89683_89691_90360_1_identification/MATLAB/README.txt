- Run "I4_PlantModelIdentification_nA_3.m" to perform the identification of the fourth order model. Identification data for this model can be found in "./DATA/4_PlantModelIdentification01/identification.mat". (~ 8 min)
- Run "I4_PlantModelIdentification_nA_5.m" to perform the identification of the sixth order model. Identification data for this model can be found in "./DATA/4_PlantModelIdentification02/identification.mat". (~ 20 min)
- The results in "./DATA/" are already computed, but are overridden if any of the two scripts above are run.
- All data regarding the model is found in "./model/"
- Simulink model "./barra1Validation.slx" compares the open-loop response of the plant with the response of the two postprocessed identified systems to an impulse.

[Very important! Note that due to the randomness of the PRBS signals the fitness values obtained may be slightly different than those presented in the report.]