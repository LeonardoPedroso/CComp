if ~isfile("./DATA/bodeData.mat")
     sim('./model/barra1Bode.slx',100);
end


